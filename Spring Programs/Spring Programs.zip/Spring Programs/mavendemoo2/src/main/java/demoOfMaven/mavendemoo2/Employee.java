
package demoOfMaven.mavendemoo2;

public class Employee {
String id,salary,address,name; public Employee(String id, String salary, String address, String name) {
super();
this.id = id;
this.salary = salary;
this.address = address;
this.name = name;
}
void display()
{
System.out.print("Employee deails \n ID :"+id+" Salary :"+salary+" address :"+address+" name :"+name+"\n");}
}


