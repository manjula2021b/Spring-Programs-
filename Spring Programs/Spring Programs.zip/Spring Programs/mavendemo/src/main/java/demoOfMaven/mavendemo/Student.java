package demoOfMaven.mavendemo;

public class Student {

	String name;
	int roll;
	
	public Student() {
		
	}

	public Student(int roll)
	{
		super();
		this.roll=roll;
	}
	public Student(String name)
	{
		super();
		this.name=name;
	}

	public Student(String name, int roll) {
		super();
		this.name = name;
		this.roll = roll;
	}
	
	void display()
	{
		System.out.println("Name :"+name+"Roll no :"+roll);
	}
	

}
