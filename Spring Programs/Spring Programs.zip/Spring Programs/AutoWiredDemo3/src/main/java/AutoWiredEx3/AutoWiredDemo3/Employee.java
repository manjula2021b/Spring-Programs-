package AutoWiredEx3.AutoWiredDemo3;
import org.springframework.beans.factory.annotation.Autowired;
public class Employee {
	@Autowired
			
			Salary sal;

			public Salary getsal() {
				return sal;
			}
			@Autowired
			public void setsal(Salary sal) {
				this.sal = sal;
			}
			
			void displaysal()
			{
				sal.display();
			}
		}





