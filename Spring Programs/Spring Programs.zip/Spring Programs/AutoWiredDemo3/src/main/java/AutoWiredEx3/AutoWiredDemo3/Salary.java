package AutoWiredEx3.AutoWiredDemo3;
import org.springframework.stereotype.Component;

import java.util.Scanner;
@Component

public class Salary {
			public Salary()
			{
				System.out.println("Salary of the employees is");
			}
			void display()
			{
//				System.out.println("4.5 Lac per Annum");
//			}
//		}
	int oldSalaryPerMonth;
	int hike;
	
	
	
	Scanner in = new Scanner(System.in);
	
	System.out.println("Enter your old salary per month:");
	oldSalaryPerMonth = in.nextInt();
	
	System.out.println("Enter your hike percentage:");
	hike = in.nextInt();
	
	int presentSalaryPerMonth = oldSalaryPerMonth + (oldSalaryPerMonth * hike/100);
	
	
	System.out.println("After hike your present salary per month is: " + presentSalaryPerMonth );
	}
	}
