package AutoWiredEx2.AutoWiredDemo2;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;


public class App 
{

	    public static void main( String[] args )
	    {
	    	ApplicationContext context=new ClassPathXmlApplicationContext("NewFile.xml");
	    	Student stu=(Student)context.getBean("stu");
	    	
	      stu.displayadrs();
	    }
	}


