package AutoWiredEx2.AutoWiredDemo2;
import org.springframework.beans.factory.annotation.Autowired;

public class Student {

		@Autowired
		
		Address adrs;

		public Address getadrs() {
			return adrs;
		}
		@Autowired
		public void setadrs(Address adrs) {
			this.adrs = adrs;
		}
		
		void displayadrs()
		{
			adrs.display();
		}
	}


